#pragma once
class SPIClass {};

